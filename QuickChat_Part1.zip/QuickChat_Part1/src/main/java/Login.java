import java.util.regex.Pattern;

/**
 * Login class for the QuickChat registration and login feature.
 *
 * This class stores a user's registration details and has methods to
 * check if their username, password and cell phone number were typed
 * in correctly. It also handles logging the user back in.
 *
 * Reference:
 * I used a regex tutorial website to help me understand how to write
 * the pattern for checking a South African cell phone number (the +27
 * country code followed by 9 digits).
 * Source: regex101.com. (n.d.) Regex Tutorial. Available at:
 * https://regex101.com/ (Accessed: September 2026).
 */
public class Login {

    // These are the details the user typed in when they registered.
    private String username;
    private String password;
    private String cellNumber;
    private String firstName;
    private String lastName;

    public Login(String username, String password, String cellNumber, String firstName, String lastName) {
        this.username = username;
        this.password = password;
        this.cellNumber = cellNumber;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    /**
     * Checks that the username contains an underscore and is not more
     * than five characters long.
     */
    public boolean checkUserName(String username) {
        if (username == null) {
            return false;
        }
        return username.contains("_") && username.length() <= 5;
    }

    /**
     * Checks that the password is at least 8 characters long, and
     * contains a capital letter, a number, and a special character.
     */
    public boolean checkPasswordComplexity(String password) {
        if (password == null) {
            return false;
        }

        boolean isLongEnough = password.length() >= 8;
        boolean hasCapitalLetter = Pattern.compile("[A-Z]").matcher(password).find();
        boolean hasNumber = Pattern.compile("[0-9]").matcher(password).find();
        // Anything that isn't a letter or a number counts as a special character.
        boolean hasSpecialCharacter = Pattern.compile("[^a-zA-Z0-9]").matcher(password).find();

        return isLongEnough && hasCapitalLetter && hasNumber && hasSpecialCharacter;
    }

    /**
     * Checks that the cell phone number starts with the South African
     * country code (+27) and is followed by exactly 9 digits (so the
     * whole number, including the country code, is not more than ten
     * "sections" long, as required in the brief).
     */
    public boolean checkCellPhoneNumber(String cellNumber) {
        if (cellNumber == null) {
            return false;
        }
        return Pattern.matches("^\\+27[0-9]{9}$", cellNumber);
    }

    /**
     * Checks the username and password that were captured when this
     * Login object was created, and returns the message that should be
     * displayed to the user.
     */
    public String registerUser() {
        if (!checkUserName(this.username)) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }

        if (!checkPasswordComplexity(this.password)) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }

        return "Username successfully captured.\nPassword successfully captured.";
    }

    /**
     * Compares the username and password entered at login with the
     * ones that were saved when the user registered.
     */
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return this.username.equals(enteredUsername) && this.password.equals(enteredPassword);
    }

    /**
     * Returns the correct message depending on whether the login was
     * successful or not.
     */
    public String returnLoginStatus(boolean loginSuccessful) {
        if (loginSuccessful) {
            return "Welcome " + firstName + ", " + lastName + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    // Small getters, just in case they are needed elsewhere.
    public String getUsername() {
        return username;
    }

    public String getCellNumber() {
        return cellNumber;
    }
}
