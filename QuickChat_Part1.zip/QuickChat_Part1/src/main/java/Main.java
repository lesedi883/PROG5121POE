import java.util.Scanner;

/**
 * QuickChat - Part 1: Registration and Login
 *
 * This console app lets a user register an account (username, password,
 * first name, last name and South African cell phone number) and then
 * log back into that same account.
 *
 * No GUI is used, as required by the brief - everything runs through
 * the console using Scanner.
 */
public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("===================================");
        System.out.println(" Welcome to QuickChat Registration ");
        System.out.println("===================================");

        Login login = null;
        boolean registeredSuccessfully = false;

        // Keep looping until the user manages to register with valid details.
        while (!registeredSuccessfully) {

            System.out.print("Enter a username (must contain an underscore and be 5 characters or less): ");
            String username = scanner.nextLine();

            System.out.print("Enter a password (8+ characters, a capital letter, a number and a special character): ");
            String password = scanner.nextLine();

            System.out.print("Enter your first name: ");
            String firstName = scanner.nextLine();

            System.out.print("Enter your last name: ");
            String lastName = scanner.nextLine();

            System.out.print("Enter your South African cell phone number (e.g. +27831234567): ");
            String cellNumber = scanner.nextLine();

            login = new Login(username, password, cellNumber, firstName, lastName);

            // First check the username and password.
            String registerMessage = login.registerUser();
            System.out.println(registerMessage);

            if (registerMessage.contains("not correctly formatted")) {
                System.out.println("Please try registering again.\n");
                continue;
            }

            // Username and password were fine, now check the cell phone number.
            if (login.checkCellPhoneNumber(cellNumber)) {
                System.out.println("Cell phone number successfully added.");
            } else {
                System.out.println("Cell phone number incorrectly formatted or does not contain international code.");
                System.out.println("Please try registering again.\n");
                continue;
            }

            registeredSuccessfully = true;
        }

        System.out.println("\nYou are registered! Now let's log you in.");
        System.out.println("===================================");

        System.out.print("Enter your username: ");
        String loginUsername = scanner.nextLine();

        System.out.print("Enter your password: ");
        String loginPassword = scanner.nextLine();

        boolean loginSuccessful = login.loginUser(loginUsername, loginPassword);
        String loginStatusMessage = login.returnLoginStatus(loginSuccessful);
        System.out.println(loginStatusMessage);

        scanner.close();
    }
}
